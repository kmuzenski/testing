<?php
$string =str_split( "I love kitties");


$i=0;

foreach ($string as $str) {
$i++;
}
print_r ($i);

?> 
