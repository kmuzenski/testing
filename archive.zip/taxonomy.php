<?php

class Eukarya {
public function Domain(){
print_r("Domain -Eukarya");
}
}

class Animalia extends Eukarya {
public function Kingdom(){
print_r("Kingdom-Animalia");
}
}

class Chordata extends Animalia {
public function Phylum() {
print_r("Phylum-Chordata");
}
}

class Mammalia extends Chordata{
public function Klass() {
print_r("Class -Mammalia");
}
}

class Primates extends Mammalia {
public function Order() {
print_r("Order-Primates");
}
}

class Hominidae extends Primates{
public function Family() {
print_r("Family-Hominidae");
}
}

class Homo extends Homindae {
public function Genus() {
print_r("Genus-Homo");
}
}

class HomoSapien extends Homo {
public function Species() {
print_r("Species-HomoSapien");
}

$printTaxonomy = new Eukarya();
$printTaxonomy->Domain();
$printTaxonomy->Kingdom();
$printTaxonomy->Phylum();
$printTaxonomy->Klass();
$printTaxonomy->Order();
$printTaxonomy->Family();
$printTaxonomy->Genus();
$printTaxonomy->Species();


?>
