<?php
	function combo($mv1,$mv2,$mv3,$mv4,$mv5,$mv6,$mv7,$mv8,$mv9,$mv10,$mv11){ 
	echo $mv1."\n";
	echo $mv2."\n";
	echo $mv3."\n";
	echo $mv4."\n";
	echo $mv5."\n";
	echo $mv6."\n";
	echo $mv7."\n";
	echo $mv8."\n";
	echo $mv9."\n";	
	echo $mv10."\n";
	echo $mv11."\n";

}

	
	echo combo("up","up","down","down","left","right","left","right","B","A","Start");
?> 

