<?php

class Distance {

function inches() {
$init = 500;
$miles = floor($init / 63360);
$yards = floor($init/ 36);
$feet = floor($init/ 12);
$inches = $init % 12;


echo "$miles $yards $feet $inches";
}
}

$length = new Distance();
$length->inches();

?>
