<?php

$i =0;

for ($i=0;$i<10;$i++) {
echo "the number is $i \n";
}

?>
