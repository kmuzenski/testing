<?php

$text = "A coincidence is always possible, but only a fool would have jotted this down under 'luck.' When I left the police station my head was still spinning. One of the cops said I was lucky to still have a head, but I thought he wasn't giving me enough credit. The bulldozer was coming for my legs first, I'd at least have swung my torso out of the way.
The construction workers were, of course, apologetic, and I had noticed the site at least a month before -- a new store, or something, going up, so they'd brought in the heavy equipment. Really it had never occurred to me that it would become so dangerous, or I'd have walked on the other side.
They assured me two and three times over that it was very, very rare for a piece of equipment to get out of control like that, let alone go careening for the sidewalk. To be fair, I was almost more embarrassed than they were. I'm usually a pretty fast guy, and it was only because I was tripped up by a garbage can that I ended up in the path of the dozer.
At any rate, I was still alive, so the focus on me didn't last long. Eventually all the involved parties -- the cops, the construction workers, some witnesses (and me, trapped doing paperwork) -- were gathered in the lobby of the police station a few blocks down. The squirrel had captured everyone's imagination.
I'd just assumed someone had hopped back in the dozer and swerved into the road before it got to me, but the workers testified that they'd come nowhere close to it. Jimmy, the guy who'd left it going, never reached it. But the dozer had obviously changed direction, and they were all wondering whether the squirrel that had hopped out of the cockpit had had anything to do with it.
I had nothing to say about it, and left the station as soon as they'd let me. Even though they said their agency would call I doubted that I'd be getting back to them.
I took the other side of the street on the way back. Of course I'd seen the squirrel too, but I'd seen it last. To me it seemed like the squirrel had climbed out of one of the city trees and scampered away after the commotion. But deep down I knew there was more, because when the squirrel got to the end of the block he paused and looked straight at me. Rearing up, he stood as tall as he could and -- curse my poor eyesight -- almost looked to be raising a paw in the air with an attitude that implied goodbye. I rose when I saw him and from a higher angle I
 
saw that the gesture was being delivered almost with reverence. Then he bowed against the concrete, and the windless summer day presented him flat against the earth. Hot and still. If a squirrel had lain like that a few feet back -- in the road -- it would've been mistaken for roadkill.
I was quickening my pace away from the sidewalk scene. I knew I'd seen the squirrel before, but a torrent of tears came to me at the same time. I'd seen many squirrels before the bumper of my car and it was this one -- only this one alone -- who'd made it.";

$words = explode (" ", $text);
$counts = array_count_values($words);
$maxs= array_keys($counts, max($counts));

print_r($maxs);

?>
