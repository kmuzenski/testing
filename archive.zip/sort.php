<?php
 

	class reverseSort {

		public function sorted() {

		$listOne = array(1,3,5);
   
		$listTwo = array(2,4,6);
		$listThree= array_merge($listOne,$listTwo);	
		arsort($listThree);
		print_r($listThree);
		}

}

       		
$final = new reverseSort();
$final ->sorted();

?>




