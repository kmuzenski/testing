<?php

class calculateSeconds {


function Seconds() {
$init= 685000;
$days = floor($init /86400);
$hours = floor($init / 3600);
$minutes = floor(($init / 60) % 60);
$seconds = $init % 60;

echo "$days:$hours:$minutes:$seconds";
}
}

$Time = new CalculateSeconds();
$Time->Seconds();




?>

