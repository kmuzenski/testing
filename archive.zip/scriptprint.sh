#!/bin/bash

echo "Kathryn Muzenski"

php -v

python -V
